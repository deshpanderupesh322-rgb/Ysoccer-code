xgettext --language=C --from-code=UTF-8 --add-comments --output=template.pot  `find .. -type f -name "*.bmx"` &> /dev/null
