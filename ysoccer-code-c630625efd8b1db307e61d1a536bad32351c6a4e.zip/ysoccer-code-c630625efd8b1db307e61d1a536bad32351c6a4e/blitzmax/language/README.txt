I suggest to use Poedit for creating and editing the po files.
To add a new language file:
File > New catalog from pot file... and select template.pot 
