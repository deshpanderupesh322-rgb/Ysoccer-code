package com.ygames.ysoccer.export;

import java.util.ArrayList;
import java.util.List;

public class Config {

    public List<FileConfig> files = new ArrayList<FileConfig>();

}
