package com.ygames.ysoccer.database;

import com.ygames.ysoccer.match.Team;

public class ImportFileConfig {
    public String filename;
    public Team.Type type;
    public String country;
    public String[] leagues;
    public String continent;
}
