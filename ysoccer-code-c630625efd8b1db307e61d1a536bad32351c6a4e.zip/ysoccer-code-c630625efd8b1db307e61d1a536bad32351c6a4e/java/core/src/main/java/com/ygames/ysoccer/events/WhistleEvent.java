package com.ygames.ysoccer.events;

public class WhistleEvent extends GameEvent {
}
