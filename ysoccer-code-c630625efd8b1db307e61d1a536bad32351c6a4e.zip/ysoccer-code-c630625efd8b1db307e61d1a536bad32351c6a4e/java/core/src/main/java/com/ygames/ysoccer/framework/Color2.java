package com.ygames.ysoccer.framework;

public class Color2 {

    public int color1;
    public int color2;

    public Color2(int color1, int color2) {
        this.color1 = color1;
        this.color2 = color2;
    }
}
