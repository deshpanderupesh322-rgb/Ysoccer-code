package com.ygames.ysoccer.events;

public class PeriodStopEvent extends GameEvent {
}
