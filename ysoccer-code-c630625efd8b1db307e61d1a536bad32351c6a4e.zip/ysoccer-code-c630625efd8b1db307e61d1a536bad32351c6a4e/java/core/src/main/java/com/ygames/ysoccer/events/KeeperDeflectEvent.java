package com.ygames.ysoccer.events;

public class KeeperDeflectEvent extends GameEvent {
}
