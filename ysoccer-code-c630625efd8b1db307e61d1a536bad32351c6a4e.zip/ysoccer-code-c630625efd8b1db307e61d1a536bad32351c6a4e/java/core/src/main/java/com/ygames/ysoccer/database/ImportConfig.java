package com.ygames.ysoccer.database;

import java.util.ArrayList;
import java.util.List;

public class ImportConfig {

    public List<ImportFileConfig> files = new ArrayList<ImportFileConfig>();
}
