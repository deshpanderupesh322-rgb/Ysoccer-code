package com.ygames.ysoccer.events;

public class CelebrationEvent extends GameEvent {
}
