package com.ygames.ysoccer.events;

public abstract class GameEvent {
}
