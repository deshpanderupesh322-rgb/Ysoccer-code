package com.ygames.ysoccer.events;

public class MatchIntroEvent extends GameEvent {
}
