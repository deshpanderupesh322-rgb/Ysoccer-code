package com.ygames.ysoccer.events;

public class CrowdChantsEvent extends GameEvent {

    public CrowdChantsEvent() {
    }
}
