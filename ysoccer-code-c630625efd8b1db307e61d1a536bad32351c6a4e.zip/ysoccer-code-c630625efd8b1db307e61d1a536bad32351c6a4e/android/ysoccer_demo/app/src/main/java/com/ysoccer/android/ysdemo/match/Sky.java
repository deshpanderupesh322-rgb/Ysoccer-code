package com.ysoccer.android.ysdemo.match;

public class Sky {

    public static final int CLEAR = 0;
    public static final int CLOUDY = 1;

}
