package com.ysoccer.android.ysdemo.match;

public class Data {

    public int x;
    public int y;
    public int z;
    public int fmx;
    public int fmy;
    public boolean isVisible;

}
