package com.ysoccer.android.ysdemo.match;

class KeeperFrame {
    int[] fmx; // top-right, top-left, bottom-right, bottom-left
    int fmy;
    int[] offx; // top-right, top-left, bottom-right, bottom-left
    int offz;
}
