package com.ysoccer.android.ysdemo.match;

import com.ysoccer.android.ysdemo.R;

public class Time {

    public static final int DAY = 0;
    public static final int NIGHT = 1;
    public static final int RANDOM = 2;

    public static int[] stringIds = {R.string.DAY, R.string.NIGHT,
            R.string.RANDOM};

}
