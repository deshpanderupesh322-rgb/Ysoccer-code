package com.ysoccer.android.ysdemo.match;

public class PlayerState extends State {

    protected final Player player;

    public PlayerState(Player player) {
        this.player = player;
    }
}
