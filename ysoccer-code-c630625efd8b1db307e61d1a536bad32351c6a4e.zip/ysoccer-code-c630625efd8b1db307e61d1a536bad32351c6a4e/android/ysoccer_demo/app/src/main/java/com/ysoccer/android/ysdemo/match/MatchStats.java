package com.ysoccer.android.ysdemo.match;

public class MatchStats {

    int goals;
    int ballPossession;
    int overallShots;
    int centeredShots;
    int cornersWon;
    int foulsConceded;
    int yellowCards;
    int redCards;

}
