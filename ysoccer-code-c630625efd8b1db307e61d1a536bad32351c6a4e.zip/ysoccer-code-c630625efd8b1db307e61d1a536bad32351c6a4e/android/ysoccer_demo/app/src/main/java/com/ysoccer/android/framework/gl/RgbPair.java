package com.ysoccer.android.framework.gl;

public class RgbPair {

    int rgbOld;
    int rgbNew;

    public RgbPair(int rgbOld, int rgbNew) {
        this.rgbOld = rgbOld;
        this.rgbNew = rgbNew;
    }

}
