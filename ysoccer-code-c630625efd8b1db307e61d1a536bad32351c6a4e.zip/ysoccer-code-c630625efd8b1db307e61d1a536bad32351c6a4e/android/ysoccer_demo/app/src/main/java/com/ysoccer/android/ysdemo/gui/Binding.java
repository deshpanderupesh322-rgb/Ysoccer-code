package com.ysoccer.android.ysdemo.gui;

public class Binding {

    public int eventType;
    public String methodName;
    String[] methodArguments;

}
