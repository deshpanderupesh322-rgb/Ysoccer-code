package com.ysoccer.android.ysdemo.match;

public class Skin {

    public static int colors[][] = {{0xF89150, 0xB85B26, 0x78311A}, // 0-pink
            {0x613E21, 0x3C2611, 0x140A01}, // 1-black
            {0xF7AE80, 0xB77651, 0x905440}, // 2-pale
            {0xF8BF50, 0xB88D26, 0x83641A}, // 3-asiatic
            {0xD98B59, 0xB45C29, 0x7C3F1C}, // 4-arab
            {0xC97E41, 0x8D643B, 0x634629}, // 5-mulatto
            {0xF37C58, 0xA9573E, 0x5E3123}, // 6-red
            {0xF89150, 0xB85B26, 0x78311A}, // 7-free
            {0xD6D6D6, 0xBEBEBD, 0xA5A5A4}, // 8-alien
            {0x34DF00, 0x0A9300, 0x075B01}, // 9-yoda
    };
}
